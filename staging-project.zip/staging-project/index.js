// page hover 
let page = document.getElementById('page');
let itemContainer = document.querySelector('.item-container');
page.addEventListener('mouseenter', function(){
    itemContainer.style.display = 'block';
});
page.addEventListener('mouseleave', function(){
    itemContainer.style.display = 'none';
});
// number changer 
let num = document.getElementById('num1');
let line = document.querySelector('.line');
let prev = document.getElementById('prevBtn');
let next = document.getElementById('nextBtn');
let second = document.querySelector('.second');
prev.addEventListener('click', function(){
    clearInterval(timer);
    decrease();
});
next.addEventListener('click', function(){
    clearInterval(timer);
    increase()
})
function increase(){
    let count = 2;
    num.innerHTML ='0'+ count;
    line.style.width = '6vw';
    setTimeout(increase, 3000);
}
function decrease(){
    let count =1;
    num.innerHTML ='0'+ count
    line.style.width  = '3vw';
    setTimeout(decrease, 3000);
    num.style.marginRight = '-10px';
}
let timer = setInterval(function(){
    increase();
},4000)
setInterval(function(){
    clearInterval(timer);
    decrease();
}, 7000);

// image slider 
let prevButton = document.getElementById('leftSlide');
let nextButton = document.getElementById('rightSlide');
let sliderDiv = document.querySelectorAll('.slideImage');
prevButton.addEventListener('click', function(){
   sliderDiv.forEach(function(slider){
    slider.style.transform += 'translate(-40%)';
    slider.style.transition = 'transform 1.5s';
   })
});
nextButton.addEventListener('click', function(){
   sliderDiv.forEach(function(slider){
slider.style.transform += 'translateX(40%)';
slider.style.transition = 'transform 1.5s';
   });
});
// interior div addition 
let images= document.querySelectorAll('.slider');
let interior = document.createElement('div');
images.forEach(function(image){
    image.addEventListener('mouseenter', function(){
let span = document.createElement('span');
    span.innerHTML = 'INTERIORS';
    let h3 = document.createElement('h3');
    h3.innerHTML = 'LOWER RIVER STREET';
    interior.appendChild(span);
    interior.appendChild(h3);
    interior.classList.add('interior');
    image.appendChild(interior);
    });
    image.addEventListener('mouseleave', function(){
        interior.innerText = '';
        image.removeChild(interior);
    });
});
// section 4 javascript
let prevBlog = document.getElementById('prev-blog');
let nextBlog = document.getElementById('next-blog');
let moveNum = document.getElementById('moveNum');
let text = document.querySelectorAll('.text');
let blogImage = document.querySelectorAll('.image')
let i= 1;
   nextBlog.addEventListener('click',function(){
    i++;
    moveNum.innerHTML = i;
    if(i==5){
        i = 0;
    }
});
prevBlog.addEventListener('click', function(){
    i--;
    moveNum.innerHTML = i+'.';
    if(i==0){
        i =6;
    }
});
// data counter 
let span = document.querySelectorAll('.counter');
span.forEach(function(div){
    div.innerHTML = '';
    increment();
    function increment(){
    let text = +div.innerHTML;
    let data = div.getAttribute('data-target');
    let increase = data/15;
    text = Math.floor(text+increase);
    if(text<data){
        div.innerHTML = text;
        setTimeout(increment, 100);
    }else{
        div.innerHTML = data;
    }
    }
});

let firstDiv = document.getElementById('one');
let secondDiv = document.getElementById('two');
let threeDiv = document.getElementById('three');
let imageDiv = document.querySelectorAll('.img');
let dolo = document.getElementById('dolo');
let dana = document.getElementById('dana');
let mac = document.getElementById('mac');
let textDiv = document.querySelectorAll('.text-div');
firstDiv.addEventListener('mouseenter',function(){
   dolo.style.display = 'flex';   
    textDiv.forEach(function(){
        textDiv[0].style.display = 'none';
    })
});
dolo.addEventListener('mouseleave',function(){
    dolo.style.display = 'none';
     textDiv.forEach(function(){
        textDiv[0].style.display = 'block';
    })
})
secondDiv.addEventListener('mouseenter', function(){
    dana.style.display = 'flex';
    textDiv.forEach(function(){
        textDiv[1].style.display = 'none';
    })
});
dana.addEventListener('mouseleave', function(){
    dana.style.display = 'none';
    textDiv.forEach(function(){
        textDiv[1].style.display = 'block';
    });
});
threeDiv.addEventListener('mouseenter', function(){
    mac.style.display = 'flex';
     textDiv.forEach(function(){
        textDiv[2].style.display = 'none';
    });
});
mac.addEventListener('mouseleave', function(){
    mac.style.display = 'none';
     textDiv.forEach(function(){
        textDiv[2].style.display = 'block';
    });
});
// section 7 javascript
let blogDiv = document.querySelectorAll('.blog-div');
let leftLin = document.querySelectorAll('.leftLin');
let rightLin = document.querySelectorAll('.rightLin');
blogDiv.forEach(function(){
    blogDiv[0].addEventListener('mouseenter', function(){
        leftLin.forEach(function(){
            leftLin[0].style.display = 'none';
        });
        rightLin.forEach(function(){
            rightLin[0].style.display = 'block';
        });
    });
    blogDiv[0].addEventListener('mouseleave', function(){
        leftLin.forEach(function(){
            leftLin[0].style.display = 'block';
        });
        rightLin.forEach(function(){
            rightLin[0].style.display = 'none';
        })
    })
    blogDiv[1].addEventListener('mouseenter', function(){
        leftLin.forEach(function(){
            leftLin[1].style.display = 'none';
        });
        rightLin.forEach(function(){
            rightLin[1].style.display = 'block';
        });
    });
    blogDiv[1].addEventListener('mouseleave', function(){
        leftLin.forEach(function(){
            leftLin[1].style.display = 'block';
        });
        rightLin.forEach(function(){
            rightLin[1].style.display = 'none';
        })
    })
    blogDiv[2].addEventListener('mouseenter', function(){
        leftLin.forEach(function(){
            leftLin[2].style.display = 'none';
        });
        rightLin.forEach(function(){
            rightLin[2].style.display = 'block';
        });
    });
    blogDiv[2].addEventListener('mouseleave', function(){
        leftLin.forEach(function(){
            leftLin[2].style.display = 'block';
        });
        rightLin.forEach(function(){
            rightLin[2].style.display = 'none';
        })
    })
});


    
   
